<template>
  <div>
    <el-image
      style="width: 81%;"
      src="./index.jpg"
    ></el-image>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'

</script>
<style scoped>

</style>